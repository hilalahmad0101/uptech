jQuery(document).ready(function() {
        jQuery(function () {
            jQuery('#defaultCountdown').countdown({until: new Date(2023, 11, 3, 8)}); // year, month, date, hour
        });
});		

